# platzi-ejemplos-api-rest
Ejemplos usados en el curso de API REST
