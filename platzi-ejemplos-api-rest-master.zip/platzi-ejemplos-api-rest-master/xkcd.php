<?php

echo file_get_contents('https://xkcd.com/info.0.json').PHP_EOL;
